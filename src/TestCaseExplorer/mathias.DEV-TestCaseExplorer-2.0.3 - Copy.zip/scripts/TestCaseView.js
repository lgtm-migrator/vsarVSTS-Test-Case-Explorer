//---------------------------------------------------------------------
// <copyright file="TestCaseView.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file contains the view logic
//    for the test case view.
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "VSS/Controls", "VSS/Controls/Grids", "VSS/Controls/Menus", "VSS/Controls/Dialogs", "TFS/WorkItemTracking/Contracts", "TFS/WorkItemTracking/RestClient", "VSS/Controls/Navigation", "VSS/Controls/StatusIndicator", "TFS/WorkItemTracking/Services", "scripts/TestCaseDataService", "scripts/Common", "scripts/ColumnsOptionsView"], function (require, exports, Controls, Grids, Menus, Dialogs, WorkItemContracts, WorkItemClient, Navigation, StatusIndicator, WorkItemServices, TestCaseDataService, Common, ColumnOptionsView) {
    "use strict";
    var TestCaseView = (function () {
        function TestCaseView() {
            this._showTestResults = false;
            this._commonField = [
                { field: "System.Id", name: "Id", width: 75 },
                { field: "System.Title", name: "Title", width: 250 },
                { field: "System.State", name: "State", width: 75 },
                { field: "System.AssignedTo", name: "Assigned to", width: 150 },
                { field: "Microsoft.VSTS.Common.Priority", name: "Priority", width: 50 },
                { field: "Microsoft.VSTS.TCM.AutomationStatus", name: "Automation Status", width: 100 }
            ];
            this._currentFilter = null;
            this._orphanTestCaseFilter = null;
            this._testSuiteFilter = null;
        }
        TestCaseView.prototype.RefreshGrid = function (pivot, value, showRecursive) {
            var view = this;
            this._grid.setDataSource(null);
            $("#grid-title").text("");
            this.StartLoading(true, "Fetching data");
            var promise;
            var title;
            this._selectedPivot = pivot;
            this._selectedValue = value;
            this._showRecursive = showRecursive;
            this._selectedValueWithField = null;
            var fieldLst = this._fields.map(function (f) { return f.field; });
            switch (pivot) {
                case "Area path":
                    promise = TestCaseDataService.getTestCasesByProjectStructure(WorkItemContracts.TreeNodeStructureType.Area, value.path, showRecursive, fieldLst);
                    title = "Test cases with area path: " + value.path;
                    this._selectedValueWithField = { "System.AreaPath": value.path };
                    this._fields = Common.MergeColumnLists(this._fields, [{ field: "System.AreaPath", name: "Area Path", width: 200 }]);
                    break;
                case "Iteration path":
                    promise = TestCaseDataService.getTestCasesByProjectStructure(WorkItemContracts.TreeNodeStructureType.Iteration, value.path, showRecursive, fieldLst);
                    title = "Test cases with iteration path: " + value.path;
                    this._selectedValueWithField = { "System.IterationPath": value.path };
                    this._fields = Common.MergeColumnLists(this._fields, [{ field: "System.IterationPath", name: "Iteration Path", width: 200 }]);
                    break;
                case "Priority":
                    var priority = "any";
                    if (value.name != "Priority") {
                        priority = value.name;
                        this._selectedValueWithField = { "Priority": value.name };
                    }
                    promise = TestCaseDataService.getTestCasesByPriority(priority, fieldLst);
                    title = "Test cases with priority: " + priority;
                    break;
                case "State":
                    var state = "any";
                    if (value.name != "States") {
                        state = value.name;
                    }
                    promise = TestCaseDataService.getTestCasesByState(state, fieldLst);
                    title = "Test cases with state: " + state;
                    break;
                case "Test plan":
                    promise = TestCaseDataService.getTestCasesByTestPlan(value.testPlanId, value.suiteId, fieldLst, showRecursive);
                    this._fields = Common.MergeColumnLists(this._fields, [{ field: "TC::Present.In.Suite", name: "Present in suites", width: 150 }]);
                    title = "Test suite: " + value.name + " (Suite Id: " + value.suiteId + ")";
                    break;
            }
            $("#grid-title").text(title);
            promise.then(function (result) {
                view._data = result;
                if (view._showTestResults) {
                    var outcomeFields = [
                        { field: "Outcome", name: "Last Outcome", width: 100, getCellContents: Common.getTestResultCellContent },
                        { field: "TestedDate", name: "Last tested date", width: 150 }];
                    view._fields = Common.MergeColumnLists(view._fields, outcomeFields);
                    TestCaseDataService.getTestResultsForTestCases(view._data.map(function (i) { return i["System.Id"]; })).then(function (data) {
                        data.forEach(function (r) {
                            var testCaseId = r.testCase.id;
                            var row = view._data.filter(function (i) { return i["System.Id"] == testCaseId; })[0];
                            row["Outcome"] = r.outcome;
                            row["TestedDate"] = r.lastUpdatedDate;
                            row["TestedBy"] = r.runBy.displayName;
                            row["TestDuration"] = r.durationInMs;
                        });
                        view.DoRefreshGrid();
                    }, function (err) {
                    });
                }
                view.DoRefreshGrid();
                view.DoneLoading();
            }, function (err) {
                TelemetryClient.getClient().trackException(err);
                console.log(err);
                view.DoneLoading();
            });
        };
        TestCaseView.prototype.toggle = function () {
        };
        TestCaseView.prototype.initialize = function (paneToggler, selectCallBack) {
            var view = this;
            TelemetryClient.getClient().trackPageView("TestCaseView");
            this._paneToggler = paneToggler;
            this._fields = this._commonField;
            this.loadColumnsSettings().then(function (userColumns) {
                view._fields = userColumns;
            });
            this.initMenu(this, paneToggler);
            this.initFilter(this);
            this.initGrid(this, selectCallBack);
        };
        TestCaseView.prototype.initMenu = function (view, paneToggler) {
            var menuItems = [
                { id: "new-testcase", text: "New", title: "Create test case", icon: "icon-add-small" },
                { id: "open-testcase", showText: false, title: "Open test case", icon: "icon-open" },
                { id: "refresh", showText: false, title: "Refresh grid", icon: "bowtie-navigate-refresh", cssClass: "bowtie-icon" },
                { separator: true },
                { id: "column-options", text: "Column options", title: "Choose columns for the grid", noIcon: true },
                //{ id: "latestTestResult", text: "Show TestResults", title: "Show latest test results", icon: "test-outcome-node-icon" },
                { id: "toggle", showText: false, title: "Show/hide details pane", icon: "bowtie-details-pane", cssClass: "right-align bowtie-icon" }
            ];
            var menubarOptions = {
                items: menuItems,
                executeAction: function (args) {
                    var command = args.get_commandName();
                    switch (command) {
                        case "toggle":
                            paneToggler.toggleDetailsPane();
                            menubar.updateCommandStates([{ id: command, toggled: view._paneToggler._isTestCaseDetailsPaneOn() }]);
                            break;
                        case "new-testcase":
                            WorkItemServices.WorkItemFormNavigationService.getService().then(function (workItemService) {
                                workItemService.openNewWorkItem(Common.WIQLConstants.getWiqlConstants().TestCaseTypeName, view._selectedValueWithField);
                            });
                            break;
                        case "open-testcase":
                            WorkItemServices.WorkItemFormNavigationService.getService().then(function (workItemService) {
                                var item = view._grid.getRowData(view._grid.getSelectedDataIndex());
                                workItemService.openWorkItem(item["System.Id"]);
                            });
                            break;
                        case "latestTestResult":
                            view._showTestResults = !view._showTestResults;
                            view.RefreshGrid(view._selectedPivot, view._selectedValue, view._showRecursive);
                            menubar.updateCommandStates([{ id: command, toggled: view._showTestResults }]);
                            break;
                        case "column-options":
                            view.openColumnOptionsDlg();
                            break;
                        case "refresh":
                            view.RefreshGrid(view._selectedPivot, view._selectedValue, view._showRecursive);
                            break;
                        default:
                            alert("Unhandled action: " + command);
                            break;
                    }
                }
            };
            var menubar = Controls.create(Menus.MenuBar, $("#menu-container"), menubarOptions);
            this._menubar = menubar;
            menubar.updateCommandStates([{ id: "toggle", toggled: view._paneToggler._isTestCaseDetailsPaneOn() }]);
        };
        TestCaseView.prototype.openColumnOptionsDlg = function () {
            var view = this;
            var extensionContext = VSS.getExtensionContext();
            var dlgContent = $("#columnOptionsDlg").clone();
            dlgContent.show();
            dlgContent.find("#columnOptionsDlg").show();
            var coView = new ColumnOptionsView.ColumnOptionsView();
            view._grid._columns.forEach(function (c) {
                var f = view._fields.filter(function (f) { return f.field === c.index; })[0];
                f.width = c.width;
            });
            var fieldsToManage = this._fields.filter(function (f) { return f.field.indexOf("TC::") == -1; });
            coView.Init(dlgContent, fieldsToManage);
            var options = {
                width: 800,
                height: 500,
                title: "Column Options",
                content: dlgContent,
                okCallback: function (result) {
                    view._fields = coView.GetSelectedColumns();
                    view.RefreshGrid(view._selectedPivot, view._selectedValue, view._showRecursive);
                    view.saveColumnsSettings();
                }
            };
            var dialog = Dialogs.show(Dialogs.ModalDialog, options);
            dialog.updateOkButton(true);
            dialog.setDialogResult(true);
        };
        TestCaseView.prototype.saveColumnsSettings = function () {
            var view = this;
            VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                // Set value in user scope
                dataService.setValue("SelectedColumns_" + VSS.getWebContext().project.id, JSON.stringify(view._fields), { scopeType: "User" });
            });
        };
        TestCaseView.prototype.loadColumnsSettings = function () {
            var view = this;
            var deferred = $.Deferred();
            VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                // Set value in user scope
                dataService.getValue("SelectedColumns_" + VSS.getWebContext().project.id, { scopeType: "User" }).then(function (data) {
                    if (data != undefined) {
                        deferred.resolve(JSON.parse(data));
                    }
                    else {
                        view.localizeCommonFields().then(function (cmflds) {
                            view._commonField = view._commonField;
                            deferred.resolve(view._commonField);
                        }, function (err) {
                            deferred.resolve(view._commonField);
                        });
                    }
                }, function (err) {
                    view.localizeCommonFields().then(function (cmflds) {
                        view._commonField = view._commonField;
                        deferred.resolve(view._commonField);
                    }, function (err) {
                        deferred.resolve(view._commonField);
                    });
                });
            });
            return deferred.promise();
        };
        TestCaseView.prototype.localizeCommonFields = function () {
            var view = this;
            var deferred = $.Deferred();
            var witClient = WorkItemClient.getClient();
            var ctx = VSS.getWebContext();
            witClient.getWorkItemType(ctx.project.id, Common.WIQLConstants.getWiqlConstants().TestCaseTypeName).then(function (wit) {
                view._commonField.forEach(function (f) {
                    f.name = wit["fieldInstances"].filter(function (i) { return i.field.referenceName === f.field; })[0].field.name;
                });
                deferred.resolve(view._commonField);
            }, function (err) {
                deferred.resolve(view._commonField);
            });
            return deferred.promise();
        };
        TestCaseView.prototype.initFilter = function (view) {
            TelemetryClient.getClient().trackPageView("Details.PartOfTestSuit");
            Controls.create(Navigation.PivotFilter, $("#grid-filter"), {
                behavior: "dropdown",
                text: "Filter",
                items: [
                    { id: "All", text: "All", selected: true },
                    { id: "TC_WithOUT_Requirement", text: "Tests not associated with any requirements" },
                    { id: "TC_With_Requirement", text: "Tests with requirements linking" },
                    { id: "TC_OrphanedSuites", text: "Tests not present in any suites (orphaned)" },
                    { id: "TC_MultipleSuites", text: "Tests present in multiple suites" }
                ],
                change: function (item) {
                    var command = item.id;
                    var filterPromise;
                    var filterMode;
                    var filterData;
                    switch (command) {
                        case "TC_WithOUT_Requirement":
                            filterPromise = view.getOrphanTestCaseFilter(TestCaseDataService.filterMode.Contains);
                            break;
                        case "TC_With_Requirement":
                            filterPromise = view.getOrphanTestCaseFilter(TestCaseDataService.filterMode.NotContains);
                            break;
                        case "TC_MultipleSuites":
                            filterPromise = view.getTestSuiteFilter(TestCaseDataService.filterMode.Contains);
                            break;
                        case "TC_OrphanedSuites":
                            filterPromise = view.getTestSuiteFilter(TestCaseDataService.filterMode.NotContains);
                            break;
                        default:
                            var deferred = $.Deferred();
                            deferred.resolve(null);
                            filterPromise = deferred.promise();
                            break;
                    }
                    ;
                    filterPromise.then(function (filter) {
                        view._currentFilter = filter;
                        view.DoRefreshGrid();
                    }, function (err) {
                        TelemetryClient.getClient().trackException(err);
                        console.log(err);
                    });
                }
            });
        };
        TestCaseView.prototype.initGrid = function (view, selectCallBack) {
            var _this = this;
            var options = {
                height: "100%",
                width: "100%",
                columns: this._fields.map(function (f) {
                    return { index: f.field, text: f.name, width: f.width };
                }),
                draggable: {
                    scope: "test-case-scope",
                    axis: "",
                    containment: "",
                    appendTo: document.body,
                    revert: "invalid",
                    refreshPositions: true,
                    scroll: false,
                    distance: 10,
                    cursorAt: { top: -5, left: -5 },
                    helper: function (event, ui) {
                        var $dragTile;
                        var draggableItemText, numOfSelectedItems;
                        var selectedWorkItemIds = view._selectedRows;
                        numOfSelectedItems = selectedWorkItemIds.length;
                        $dragTile = $("<div />")
                            .addClass("drag-tile");
                        var $dragItemCount = $("<div />")
                            .addClass("drag-tile-item-count")
                            .text(numOfSelectedItems);
                        var $dragType = $("<span />")
                            .addClass("drag-tile-drag-type")
                            .text(view._selectedPivot == "Test plan" ? "Move" : "Attach");
                        var $dragHead = $("<div />")
                            .addClass("drag-tile-head")
                            .append($dragType)
                            .append($dragItemCount);
                        $dragTile.append($dragHead);
                        $dragTile.data("WORK_ITEM_IDS", selectedWorkItemIds.map(function (i) { return i["System.Id"]; }));
                        $dragTile.data("MODE", "TEST_CASE");
                        return $dragTile;
                    }
                },
                openRowDetail: function (index) {
                    var item = _this._grid.getRowData(index);
                    selectCallBack(item["System.Id"]);
                    WorkItemServices.WorkItemFormNavigationService.getService().then(function (workItemService) {
                        workItemService.openWorkItem(item["System.Id"]);
                    });
                }
            };
            // Create the grid in a container element
            this._grid = Controls.create(Grids.Grid, $("#grid-container"), options);
            $("#grid-container").bind(Grids.GridO.EVENT_SELECTED_INDEX_CHANGED, function (eventData) {
                var item = view._grid.getRowData(view._grid.getSelectedDataIndex());
                view._selectedRows = getSelectedWorkItemIds(view._grid);
                if (item != null) {
                    var s = item["System.Id"];
                    selectCallBack(s);
                }
            });
        };
        TestCaseView.prototype.updateTogle = function (paneToggler) {
            var menubar = Controls.Enhancement.getInstance(Menus.MenuBar, $("#menu-container"));
            this._menubar.updateCommandStates([{ id: "toggle", toggled: paneToggler._isTestCaseDetailsPaneOn() }]);
        };
        TestCaseView.prototype.getOrphanTestCaseFilter = function (mode) {
            if (this._orphanTestCaseFilter == null) {
                this._orphanTestCaseFilter = new TestCaseDataService.wiqlFilter();
                this._orphanTestCaseFilter.setMode(mode);
                return this._orphanTestCaseFilter.initialize(wiqlOrphaneTC);
            }
            else {
                var deferred = $.Deferred();
                this._orphanTestCaseFilter.setMode(mode);
                deferred.resolve(this._orphanTestCaseFilter);
                return deferred.promise();
            }
        };
        TestCaseView.prototype.getTestSuiteFilter = function (mode) {
            if (this._testSuiteFilter == null) {
                this._testSuiteFilter = new TestCaseDataService.testSuiteFilter();
                this._testSuiteFilter.setMode(mode);
                return this._testSuiteFilter.initialize(this._data);
            }
            else {
                var deferred = $.Deferred();
                this._testSuiteFilter.setMode(mode);
                deferred.resolve(this._testSuiteFilter);
                return deferred.promise();
            }
        };
        TestCaseView.prototype.DoRefreshGrid = function () {
            var columns = this._fields.map(function (f) {
                return { index: f.field, text: f.name, width: f.width, getCellContents: f.getCellContents };
            });
            if (this._currentFilter != null) {
                this._grid.setDataSource(this._currentFilter.filter(this._data), null, columns);
            }
            else {
                this._grid.setDataSource(this._data, null, columns);
            }
            $("#grid-count").text("Showing " + this._grid._count + " of " + this._data.length + (this._data.length == 1 ? " test case" : " test cases"));
        };
        TestCaseView.prototype.StartLoading = function (longRunning, message) {
            $("body").css("cursor", "progress");
            if (longRunning) {
                var waitControlOptions = {
                    target: $(".wait-control-target"),
                    message: message,
                    cancellable: false,
                    cancelTextFormat: "{0} to cancel",
                    cancelCallback: function () {
                        console.log("cancelled");
                    }
                };
                this._waitControl = Controls.create(StatusIndicator.WaitControl, $(".left-hub-content"), waitControlOptions);
                this._waitControl.startWait();
            }
        };
        TestCaseView.prototype.DoneLoading = function () {
            $("body").css("cursor", "default");
            if (this._waitControl != null) {
                this._waitControl.cancelWait();
                this._waitControl.endWait();
                this._waitControl = null;
            }
        };
        return TestCaseView;
    }());
    exports.TestCaseView = TestCaseView;
    function getSelectedWorkItemIds(grid) {
        var i, len, ids = [], indices = grid.getSelectedDataIndices();
        for (i = 0, len = indices.length; i < len; i++) {
            ids.push(grid._dataSource[indices[i]]);
        }
        return ids;
    }
    ;
    var wiqlOrphaneTC = "SELECT [Source].[System.Id] FROM WorkItemLinks WHERE ([Source].[System.TeamProject] = @project AND  [Source].[System.WorkItemType] IN GROUP '" + Common.WIQLConstants.getWiqlConstants().TestCaseCategoryName + "') And ([System.Links.LinkType] <> '') And ([Target].[System.WorkItemType] IN GROUP '" + Common.WIQLConstants.getWiqlConstants().RequirementsCategoryName + "') ORDER BY [Source].[System.Id] mode(DoesNotContain)";
});
//# sourceMappingURL=TestCaseView.js.map