//---------------------------------------------------------------------
// <copyright file="DetailsView.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file contains the implementation
//    of the details view. 
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "VSS/Controls", "VSS/Controls/TreeView", "VSS/Controls/Grids", "VSS/Controls/Combos", "VSS/Controls/Menus", "VSS/Controls/StatusIndicator", "VSS/Controls/Navigation", "scripts/TreeViewDataService", "scripts/Common"], function (require, exports, Controls, TreeView, Grids, CtrlCombos, Menus, StatusIndicator, Navigation, TreeViewDataService, Common) {
    "use strict";
    var DetailsView = (function () {
        function DetailsView() {
        }
        DetailsView.prototype.initialize = function (paneToggler) {
            this._PaneLst = [];
            this._toggler = paneToggler;
            var view = this;
            var panels = [
                { id: "TestPlan", text: "Test plans" },
                { id: "TestSuites", text: "Test suites", selected: true },
                { id: "TestResults", text: "Test results" },
                { id: "Requirements", text: "Linked requirements" }
            ];
            Controls.create(Navigation.PivotFilter, $("#details-filter-container"), {
                behavior: "dropdown",
                text: "Pane",
                items: panels,
                change: function (item) {
                    var command = item.id;
                    view.ShowPanel(command);
                }
            });
            Controls.create(Navigation.PivotFilter, $("#details-filter-container"), {
                behavior: "dropdown",
                text: "Position",
                items: [
                    { id: "right", text: "Right", selected: true },
                    { id: "bottom", text: "Bottom" }
                ],
                change: function (item) {
                    var command = item.id;
                    view._toggler.setPosition(command);
                }
            });
            view.ShowPanel(panels[1].id);
        };
        DetailsView.prototype.selectionChanged = function (id) {
            if (this._selectedPane != null) {
                this._selectedMasterId = id;
                this._selectedPane.masterIdChanged(id);
            }
        };
        DetailsView.prototype.Refresh = function () {
            this.selectionChanged(this._selectedMasterId);
        };
        DetailsView.prototype.ShowPanel = function (panel) {
            if (this._selectedPane != null) {
                this._selectedPane.hide();
            }
            var pane;
            if (this._PaneLst[panel] == null) {
                switch (panel) {
                    case "TestPlan":
                        pane = new testPlanPane();
                        break;
                    case "TestResults":
                        pane = new testResultsPane();
                        break;
                    case "TestSuites":
                        pane = new partOfTestSuitesPane();
                        break;
                    case "Requirements":
                        pane = new linkedRequirementsPane();
                        break;
                }
                pane.initialize(this);
                this._PaneLst[panel] = pane;
            }
            else {
                pane = this._PaneLst[panel];
            }
            this._selectedPane = pane;
            this._selectedPane.show();
            this._selectedPane.masterIdChanged(this._selectedMasterId);
        };
        DetailsView.prototype.StartLoading = function (longRunning, message) {
            $("body").css("cursor", "progress");
            if (longRunning) {
                var waitControlOptions = {
                    target: $(".wait-control-details-target"),
                    message: message,
                    cancellable: false,
                    cancelTextFormat: "{0} to cancel",
                    cancelCallback: function () {
                        console.log("cancelled");
                    }
                };
                this._waitControl = Controls.create(StatusIndicator.WaitControl, $(".wait-control-details-target"), waitControlOptions);
                this._waitControl.startWait();
            }
        };
        DetailsView.prototype.DoneLoading = function () {
            $("body").css("cursor", "default");
            if (this._waitControl != null) {
                this._waitControl.cancelWait();
                this._waitControl.endWait();
                this._waitControl = null;
            }
        };
        return DetailsView;
    }());
    exports.DetailsView = DetailsView;
    var partOfTestSuitesPane = (function () {
        function partOfTestSuitesPane() {
        }
        partOfTestSuitesPane.prototype.initialize = function (view) {
            var options = {
                height: "100%",
                width: "100%",
                columns: [
                    {
                        text: "", index: "suiteType", width: 20, getCellContents: function (rowInfo, dataIndex, expandedState, level, column, indentIndex, columnOrder) {
                            var suiteType = this.getColumnValue(dataIndex, column.index);
                            var d = $("<div class='grid-cell'/>").width(column.width || 100);
                            var dIcon = $("<div class='testpoint-outcome-shade icon'/>").addClass(TreeViewDataService.getIconFromSuiteType(suiteType));
                            d.append(dIcon);
                            return d;
                        }
                    },
                    { text: "Id", index: "id", width: 50 },
                    { text: "Test Plan", index: "plan", width: 100 },
                    { text: "Suite", index: "suite", width: 150 },
                ],
                // This data source is rendered into the Grid columns defined above
                source: null
            };
            this._grid = Controls.create(Grids.Grid, $("#details-gridTestSuites"), options);
            var menuItems = [
                { id: "refresh", showText: false, title: "Refresh grid", icon: "bowtie-navigate-refresh", cssClass: "bowtie-icon" },
            ];
            var menubarOptions = {
                items: menuItems,
                executeAction: function (args) {
                    var command = args.get_commandName();
                    switch (command) {
                        case "refresh":
                            view.Refresh();
                            break;
                        default:
                            alert("Unhandled action: " + command);
                            break;
                    }
                }
            };
            var menubar = Controls.create(Menus.MenuBar, $("#detailsMenuBar-testSuite-container"), menubarOptions);
        };
        partOfTestSuitesPane.prototype.show = function () {
            $("#details-testSuites").css("display", "block");
            $("#details-title").text("Associated test suites");
        };
        partOfTestSuitesPane.prototype.hide = function () {
            $("#details-testSuites").css("display", "none");
        };
        partOfTestSuitesPane.prototype.masterIdChanged = function (id) {
            TelemetryClient.getClient().trackPageView("Details.PartOfTestSuite");
            var pane = this;
            if (id == null) {
                pane._grid.setDataSource(null);
            }
            else {
                TreeViewDataService.getTestSuitesForTestCase(parseInt(id)).then(function (data) {
                    if (data != null) {
                        $("#details-gridTestSuites").show();
                        pane._grid.setDataSource(data.map(function (i) { return { id: i.id, suite: i.name, plan: i.plan.name, suiteType: i.suiteType }; }));
                    }
                    else {
                        $("#details-gridTestSuites").hide();
                    }
                }, function (err) {
                    $("#details-gridTestSuites").hide();
                });
            }
        };
        return partOfTestSuitesPane;
    }());
    var testPlanPane = (function () {
        function testPlanPane() {
        }
        testPlanPane.prototype.initialize = function (view) {
            this._view = view;
            var tpp = this;
            var cboOptions = {
                mode: "drop",
                allowEdit: false,
            };
            this._cbo = Controls.create(CtrlCombos.Combo, $("#details-cboTestPlan"), cboOptions);
            TreeViewDataService.getTestPlans().then(function (data) {
                tpp._testPlans = data[0].children;
                tpp._cbo.setSource(tpp._testPlans.map(function (i) { return i.text; }));
            }, function (err) {
                console.log(err);
                TelemetryClient.getClient().trackException(err);
            });
            var treeOptionsTestPlan = {
                width: 400,
                height: "100%",
                nodes: null
            };
            var treeviewTestPlan = Controls.create(TreeView.TreeView, $("#details-treeviewTestPlan"), treeOptionsTestPlan);
            treeviewTestPlan.onItemClick = function (node, nodeElement, e) {
            };
            $("#details-cboTestPlan").change(function () {
                tpp._view.StartLoading(true, "Fetching test plan " + tpp._cbo.getText());
                var tp = tpp._testPlans[tpp._cbo.getSelectedIndex()];
                TreeViewDataService.getTestPlanAndSuites(tp.id, tp.text).then(function (data) {
                    tpp._view.DoneLoading();
                    treeviewTestPlan.rootNode.clear();
                    treeviewTestPlan.rootNode.addRange(data);
                    treeviewTestPlan._draw();
                    var gridTC = Controls.Enhancement.getInstance(Grids.GridO, $("#grid-container"));
                    $("li.node").droppable({
                        scope: "test-case-scope",
                        greedy: true,
                        tolerance: "pointer",
                        accept: function (d) {
                            return true;
                        },
                        drop: function (event, ui) {
                            var n = treeviewTestPlan.getNodeFromElement(event.target);
                            var grd = Controls.Enhancement.getInstance(Grids.Grid, $("#grid-container"));
                            var tcId = ui.draggable.context.childNodes[0].textContent;
                            var s = "Mapped test case " + tcId + " to suite " + n.config.suiteId + " in test plan " + n.config.testPlanId;
                            var div = $("<div />").text(s);
                            ui.draggable.context = div[0];
                            var targetPlanId = n.config.testPlanId;
                            var targetSuiteId = n.config.suiteId;
                            var ids = ui.helper.data("WORK_ITEM_IDS");
                            console.log("target plan id: " + targetPlanId);
                            console.log("target suite id: " + targetSuiteId);
                            console.log("ids: " + ids);
                            TreeViewDataService.mapTestCaseToSuite(VSS.getWebContext().project.name, tcId, n.config.suiteId, n.config.testPlanId).then(function (data) { alert(s); }, function (err) { alert(err); });
                        }
                    });
                }, function (err) {
                    console.log("Err fetching test plans");
                    console.log(err);
                });
            });
            var menuItems = [
                { id: "refresh", showText: false, title: "Refresh grid", icon: "bowtie-navigate-refresh", cssClass: "bowtie-icon" },
            ];
            var menubarOptions = {
                items: menuItems,
                executeAction: function (args) {
                    var command = args.get_commandName();
                    switch (command) {
                        case "refresh":
                            view.Refresh();
                            break;
                        default:
                            alert("Unhandled action: " + command);
                            break;
                    }
                }
            };
            var menubar = Controls.create(Menus.MenuBar, $("#detailsMenuBar-testPlan-container"), menubarOptions);
        };
        testPlanPane.prototype.show = function () {
            $("#details-TestPlan").css("display", "block");
            $("#details-title").text("Test plans");
        };
        testPlanPane.prototype.hide = function () {
            $("#details-TestPlan").css("display", "none");
        };
        testPlanPane.prototype.masterIdChanged = function (id) {
            TelemetryClient.getClient().trackPageView("Details.TestPlans");
            // TODO: can we do something meaningful here?
        };
        return testPlanPane;
    }());
    var testResultsPane = (function () {
        function testResultsPane() {
        }
        testResultsPane.prototype.initialize = function (view) {
            var options = {
                height: "100%",
                width: "100%",
                columns: [
                    { text: "Outcome", index: "Outcome", width: 75, getCellContents: Common.getTestResultCellContent },
                    { text: "Configuration", index: "Configuration", width: 75 },
                    { text: "Run by", index: "RunBy", width: 150 },
                    { text: "Date ", index: "Date", width: 150 },
                    { text: "Duration", index: "suite", width: 150 }
                ],
                // This data source is rendered into the Grid columns defined above
                source: null
            };
            this._grid = Controls.create(Grids.Grid, $("#details-gridTestResults"), options);
            var menuItems = [
                { id: "refresh", showText: false, title: "Refresh grid", icon: "bowtie-navigate-refresh", cssClass: "bowtie-icon" },
            ];
            var menubarOptions = {
                items: menuItems,
                executeAction: function (args) {
                    var command = args.get_commandName();
                    switch (command) {
                        case "refresh":
                            view.Refresh();
                            break;
                        default:
                            alert("Unhandled action: " + command);
                            break;
                    }
                }
            };
            var menubar = Controls.create(Menus.MenuBar, $("#detailsMenuBar-TestResults-container"), menubarOptions);
        };
        testResultsPane.prototype.hide = function () {
            $("#details-TestResults").css("display", "none");
        };
        testResultsPane.prototype.show = function () {
            $("#details-TestResults").css("display", "block");
            $("#details-title").text("Recent test results");
        };
        testResultsPane.prototype.masterIdChanged = function (id) {
            TelemetryClient.getClient().trackPageView("Details.TestResults");
            var pane = this;
            if (id == null) {
                pane._grid.setDataSource(null);
            }
            else {
                TreeViewDataService.getTestResultsForTestCase(parseInt(id)).then(function (data) {
                    var ds = data.map(function (i) { return { id: i.id, Outcome: i.outcome, Configuration: i.configuration.name, RunBy: (i.runBy == null ? "" : i.runBy.displayName), Date: i.completedDate }; });
                    pane._grid.setDataSource(ds);
                }, function (err) {
                    pane._grid.setDataSource(null);
                });
            }
        };
        return testResultsPane;
    }());
    var linkedRequirementsPane = (function () {
        function linkedRequirementsPane() {
        }
        linkedRequirementsPane.prototype.initialize = function (view) {
            var options = {
                height: "100%",
                width: "100%",
                columns: [
                    { text: "Id", index: "System.Id", width: 50 },
                    { text: "State", index: "System.State", width: 75 },
                    { text: "Title", index: "System.Title", width: 150 },
                ],
                // This data source is rendered into the Grid columns defined above
                source: null
            };
            this._grid = Controls.create(Grids.Grid, $("#details-gridReq"), options);
            var menuItems = [
                { id: "refresh", showText: false, title: "Refresh grid", icon: "bowtie-navigate-refresh", cssClass: "bowtie-icon" },
            ];
            var menubarOptions = {
                items: menuItems,
                executeAction: function (args) {
                    var command = args.get_commandName();
                    switch (command) {
                        case "refresh":
                            view.Refresh();
                            break;
                        default:
                            alert("Unhandled action: " + command);
                            break;
                    }
                }
            };
            var menubar = Controls.create(Menus.MenuBar, $("#detailsMenuBar-linkedReq-container"), menubarOptions);
        };
        linkedRequirementsPane.prototype.hide = function () {
            $("#details-linkedReq").css("display", "none");
        };
        linkedRequirementsPane.prototype.show = function () {
            $("#details-linkedReq").css("display", "block");
            $("#details-title").text("Linked requirements");
        };
        linkedRequirementsPane.prototype.masterIdChanged = function (id) {
            TelemetryClient.getClient().trackPageView("Details.LinkedRequirements");
            var pane = this;
            pane._grid.setDataSource(null);
            if (id != null) {
                TreeViewDataService.getLinkedRequirementsForTestCase(parseInt(id)).then(function (data) {
                    if (data != null) {
                        pane._grid.setDataSource(data.map(function (r) { return r.fields; }));
                    }
                    else {
                        pane._grid.setDataSource(null);
                    }
                }, function (err) {
                    pane._grid.setDataSource(null);
                });
            }
        };
        return linkedRequirementsPane;
    }());
});
//# sourceMappingURL=DetailsView.js.map