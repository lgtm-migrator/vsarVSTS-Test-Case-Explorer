//---------------------------------------------------------------------
// <copyright file="TestCaseDataService.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file implements the data 
//    services (api calls) for the test case view. 
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "TFS/WorkItemTracking/Contracts", "TFS/TestManagement/RestClient", "TFS/WorkItemTracking/RestClient", "scripts/Common", "q"], function (require, exports, WorkItemContracts, TestClient, WorkItemClient, Common, Q) {
    "use strict";
    (function (filterMode) {
        filterMode[filterMode["Contains"] = 0] = "Contains";
        filterMode[filterMode["NotContains"] = 1] = "NotContains";
    })(exports.filterMode || (exports.filterMode = {}));
    var filterMode = exports.filterMode;
    var wiqlFilter = (function () {
        function wiqlFilter() {
        }
        wiqlFilter.prototype.initialize = function (wiql) {
            var _this = this;
            var deferred = $.Deferred();
            var workItemClient = WorkItemClient.getClient();
            wiql = wiql.replace("@project", "'" + VSS.getWebContext().project.name + "'");
            workItemClient.queryByWiql({ query: wiql }, VSS.getWebContext().project.name).then(function (result) {
                if (result.queryResultType == 1) {
                    _this._listTC = result.workItems.map(function (i) { return i.id; });
                }
                deferred.resolve(_this);
            }, function (err) {
                deferred.reject(err);
            });
            return deferred.promise();
        };
        wiqlFilter.prototype.setMode = function (mode) {
            this._mode = mode;
        };
        wiqlFilter.prototype.filter = function (data) {
            var flt = this;
            return data.filter(function (i) { var exist = flt._listTC.indexOf(i["System.Id"]) >= 0; return (flt._mode == filterMode.Contains) ? exist : !exist; });
        };
        return wiqlFilter;
    }());
    exports.wiqlFilter = wiqlFilter;
    var testSuiteFilter = (function () {
        function testSuiteFilter() {
        }
        testSuiteFilter.prototype.initialize = function (data) {
            var deferred = $.Deferred();
            var testClient = TestClient.getClient();
            var que = [];
            this._listTC = [];
            var flt = this;
            data.forEach(function (item) {
                flt._listTC[item["System.Id"]] = data.indexOf(item);
                que.push(testClient.getSuitesByTestCaseId(item["System.Id"]));
            });
            Q.all(que).then(function (results) {
                results.forEach(function (suites) {
                    var id = data[results.indexOf(suites)]["System.Id"];
                    flt._listTC[id] = suites.length;
                });
                deferred.resolve(flt);
            }, function (err) {
                deferred.reject(err);
            });
            return deferred.promise();
        };
        testSuiteFilter.prototype.setMode = function (mode) {
            this._mode = mode;
        };
        testSuiteFilter.prototype.filter = function (data) {
            var flt = this;
            return data.filter(function (i) {
                var cnt = flt._listTC[i["System.Id"]];
                return (flt._mode == filterMode.Contains) ?
                    cnt > 1 :
                    cnt == 0;
            });
        };
        return testSuiteFilter;
    }());
    exports.testSuiteFilter = testSuiteFilter;
    function getTestResultsForTestCases(testCaseLst) {
        var deferred = $.Deferred();
        var tstClient = TestClient.getClient();
        var q = { query: "Select * from TestResult  WHERE TestCaseId IN (" + testCaseLst.join(",") + ") ORDER BY CreationDate DESC" };
        tstClient.getTestResultsByQuery(q, VSS.getWebContext().project.name, true).then(function (data) {
            deferred.resolve(data);
        }, function (err) {
            deferred.reject(err);
        });
        return deferred.promise();
    }
    exports.getTestResultsForTestCases = getTestResultsForTestCases;
    function getTestCasesByProjectStructure(structureType, path, recursive, fieldLst) {
        var typeField;
        switch (structureType) {
            case WorkItemContracts.TreeNodeStructureType.Area:
                typeField = "System.AreaPath";
                break;
            case WorkItemContracts.TreeNodeStructureType.Iteration:
                typeField = "System.IterationPath";
                break;
        }
        var wiqlWhere = "[" + typeField + "] " + (recursive ? "UNDER" : "=") + " '" + path + "'";
        return getTestCasesByWiql(fieldLst, wiqlWhere);
    }
    exports.getTestCasesByProjectStructure = getTestCasesByProjectStructure;
    function getTestCasesByPriority(priority, fieldLst) {
        var wiqlWhere;
        if (priority != "any") {
            wiqlWhere = "[Microsoft.VSTS.Common.Priority] = " + priority;
        }
        return getTestCasesByWiql(fieldLst, wiqlWhere);
    }
    exports.getTestCasesByPriority = getTestCasesByPriority;
    function getTestCasesByState(state, fieldLst) {
        var wiqlWhere;
        if (state != "any") {
            wiqlWhere = "[System.State] = '" + state + "'";
        }
        return getTestCasesByWiql(fieldLst, wiqlWhere);
    }
    exports.getTestCasesByState = getTestCasesByState;
    function getRecursiveChildIds(id, lst) {
        var ret = [];
        ret.push(id);
        lst.filter(function (i) { return i.parent != null && i.parent.id == id; }).forEach(function (it) {
            ret = ret.concat(getRecursiveChildIds(it.id, lst));
        });
        return ret;
    }
    function getTestCasesByTestPlan(planId, suiteId, fields, recursive) {
        var deferred = $.Deferred();
        var testClient = TestClient.getClient();
        if (recursive) {
            var idList = [];
            var tcIdList = {};
            var suite_id = suiteId;
            testClient.getTestSuitesForPlan(VSS.getWebContext().project.name, planId, true).then(function (suites) {
                var que = [];
                var suitesList = suites;
                getRecursiveChildIds(suiteId, suites).forEach(function (s) {
                    que.push(testClient.getTestCases(VSS.getWebContext().project.name, planId, s));
                });
                Q.all(que).then(function (results) {
                    for (var n = 0; n < results.length; n++) {
                        var r = results[n];
                        r.map(function (i) { return i.testCase.id; }).forEach(function (i) {
                            var x = tcIdList[i];
                            if (x == null) {
                                x = suitesList[n].name;
                            }
                            else if ($.isNumeric(x)) {
                                x++;
                            }
                            else {
                                x = 2;
                            }
                            tcIdList[i] = x;
                        });
                        idList = idList.concat(r.map(function (i) { return i.testCase.id; }));
                    }
                    if (idList.length > 0) {
                        getTestCases(idList, fields).then(function (testCases) {
                            deferred.resolve(testCases.map(function (tc) {
                                tc["TC::Present.In.Suite"] = tcIdList[tc["System.Id"]];
                                return tc;
                            }));
                        }, function (err) {
                            deferred.reject(err);
                        });
                    }
                    else {
                        deferred.resolve([]);
                    }
                }, function (err) {
                    deferred.reject(err);
                });
            });
        }
        else {
            testClient.getTestCases(VSS.getWebContext().project.name, planId, suiteId).then(function (result) {
                var idList = result.map(function (item) {
                    return item.testCase.id;
                }).map(Number);
                if (idList.length > 0) {
                    getTestCases(idList, fields).then(function (testCases) {
                        deferred.resolve(testCases);
                    });
                }
                else {
                    deferred.resolve([]);
                }
            });
        }
        return deferred.promise();
    }
    exports.getTestCasesByTestPlan = getTestCasesByTestPlan;
    function getTestCases(workItemIds, fields) {
        var deferred = $.Deferred();
        var workItemClient = WorkItemClient.getClient();
        var size = 200;
        var fieldsToFetch = fields.filter(function (f) { return f.indexOf("TC::") == -1; });
        var promises = [];
        while (workItemIds.length > 0) {
            var idsToFetch = workItemIds.splice(0, size);
            promises.push(workItemClient.getWorkItems(idsToFetch, fieldsToFetch));
        }
        Q.all(promises).then(function (resultSets) {
            var data = [];
            resultSets.forEach(function (result) {
                data = data.concat(result.map(function (i) { i.fields["System.Id"] = i.id; fixAssignedToFields(i); return i.fields; }));
            });
            deferred.resolve(data);
        }, function (err) {
            deferred.reject(err);
        });
        return deferred.promise();
    }
    function fixAssignedToFields(wi) {
        if (wi.fields["System.AssignedTo"] != null) {
            var s = wi.fields["System.AssignedTo"];
            if (s.indexOf("<") > 0) {
                wi.fields["System.AssignedTo"] = s.split("<")[0];
            }
        }
    }
    function getTestCasesByWiql(fields, wiqlWhere) {
        var deferred = $.Deferred();
        var workItemClient = WorkItemClient.getClient();
        var wiql = "SELECT System.Id ";
        wiql += " FROM WorkItems WHERE [System.TeamProject] = '" + VSS.getWebContext().project.name + "' AND [System.WorkItemType] IN GROUP '" + Common.WIQLConstants.getWiqlConstants().TestCaseCategoryName + "'  " + (wiqlWhere ? " AND " + wiqlWhere : "") + " ORDER BY [System.Id]";
        workItemClient.queryByWiql({ query: wiql }, VSS.getWebContext().project.name).then(function (result) {
            if (result.workItems.length > 0) {
                var ids = result.workItems.map(function (item) {
                    return item.id;
                }).map(Number);
                getTestCases(ids, fields).then(function (testCases) {
                    deferred.resolve(testCases);
                }, function (err) {
                    deferred.reject(err);
                });
            }
            else {
                deferred.resolve([]);
            }
        }, function (err) {
            deferred.reject(err);
        });
        return deferred.promise();
    }
});
//# sourceMappingURL=TestCaseDataService.js.map