//---------------------------------------------------------------------
// <copyright file="ColumnsOptionsView.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file contains the implementation
//    of the column options dialog.
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "TFS/WorkItemTracking/RestClient", "scripts/Common"], function (require, exports, WorkItemClient, Common) {
    "use strict";
    var ColumnOptionsView = (function () {
        function ColumnOptionsView() {
        }
        ColumnOptionsView.prototype.Init = function (content, selectedColumns) {
            var view = this;
            view.content = content;
            view._selectedColumns = selectedColumns;
            var witClient = WorkItemClient.getClient();
            var ctx = VSS.getWebContext();
            witClient.getWorkItemType(ctx.project.id, Common.WIQLConstants.getWiqlConstants().TestCaseTypeName).then(function (wit) {
                view._avaibleFields = wit["fieldInstances"];
                view.setupAvailbleGrid();
            }, function (err) {
            });
            this.setupSelectedColumnsGrid();
            this.setupMoveButtons();
            this.setupSortButtons();
        };
        ColumnOptionsView.prototype.GetSelectedColumns = function () {
            var lst = [];
            this.lstSelectedColumns.find('option').each(function (i, o) {
                var orgText = $(o).text();
                var refName = $(o).val();
                var width = parseInt($(o).attr("columnWidth"));
                orgText = orgText.substring(0, orgText.indexOf("[") - 1);
                lst.push({
                    name: orgText, field: refName, width: width
                });
            });
            return lst;
        };
        ColumnOptionsView.prototype.setupAvailbleGrid = function () {
            var _this = this;
            var view = this;
            view.lstAvailbleFields = this.content.find('#lst-column-source');
            view._avaibleFields.forEach(function (f) {
                if (_this._selectedColumns.filter(function (c) {
                    return c.field == f.referenceName;
                }).length == 0) {
                    _this.lstAvailbleFields.append($('<option>').val(f.referenceName).text(f.name));
                }
            });
            view.lstAvailbleFields.on("dblclick", function (e) { view.addColumn(); });
            this.sortSelectOptions();
        };
        ColumnOptionsView.prototype.setupSelectedColumnsGrid = function () {
            var view = this;
            this.lstSelectedColumns = this.content.find('#lst-selected-columns');
            this._selectedColumns.forEach(function (f) {
                view.lstSelectedColumns.append($('<option>').val(f.field).text(f.name + " [" + f.width + "]").attr("columnWidth", f.width));
            });
            view.lstSelectedColumns.on("dblclick", function (e) { view.removeColumn(); });
            this.lstSelectedColumns.change(function (e) {
                view.lstSelectedColumns.find(':selected').each(function (i, o) {
                    if ($(o).prev() != null) {
                        view.content.find("#cmdUp").prop('disabled', false);
                        ;
                    }
                    else {
                        view.content.find("#cmdUp").prop('disabled', true);
                        ;
                    }
                    if ($(o).next() != null) {
                        view.content.find("#cmdDown").prop('disabled', false);
                        ;
                        ;
                    }
                    else {
                        view.content.find("#cmdDown").prop('disabled', true);
                        ;
                    }
                    var width = $(this).attr("columnWidth");
                    view.content.find('#column-width').val(width);
                });
            });
            view.content.find('#column-width').change(function (e) {
                var width = view.content.find('#column-width').val();
                view.lstSelectedColumns.find(':selected').each(function (i, selected) {
                    if (i === 0) {
                        var orgText = $(selected).text();
                        var refName = $(selected).val();
                        orgText = orgText.substring(0, orgText.indexOf("[") + 1);
                        view.lstSelectedColumns.find("option:eq(" + $(selected).index() + ")").replaceWith($('<option>')
                            .val(refName)
                            .text(orgText + width + "]")
                            .attr("columnWidth", width));
                    }
                });
                var o = view.lstSelectedColumns[0];
                var old = view.lstSelectedColumns[0].style.display;
                view.lstSelectedColumns[0].style.display = 'none';
                var foo = view.lstSelectedColumns[0].offsetHeight;
                view.lstSelectedColumns[0].style.display = old;
            });
        };
        ColumnOptionsView.prototype.setupMoveButtons = function () {
            var view = this;
            this.content.find('#cmdAdd').click(function (e) {
                view.addColumn();
            });
            this.content.find('#cmdRemove').click(function (e) {
                view.removeColumn();
            });
        };
        ColumnOptionsView.prototype.setupSortButtons = function () {
            var _this = this;
            var view = this;
            this.content.find('#cmdUp').click(function (e) {
                _this.moveSelectOptions("up");
            });
            this.content.find('#cmdDown').click(function (e) {
                _this.moveSelectOptions("down");
            });
        };
        ColumnOptionsView.prototype.addColumn = function () {
            var view = this;
            var defWidth = 75;
            view.lstAvailbleFields.find(':selected').each(function (i, selected) {
                var txt = $(selected).text();
                var refName = $(selected).val();
                txt = txt + " [" + defWidth + "]";
                view.lstSelectedColumns.append($('<option>').val(refName).text(txt).attr("columnWidth", defWidth));
                view.lstAvailbleFields.find("option:eq(" + $(selected).index() + ")").remove();
            });
        };
        ColumnOptionsView.prototype.removeColumn = function () {
            var view = this;
            view.lstSelectedColumns.find(':selected').each(function (i, selected) {
                var txt = $(selected).text();
                var refName = $(selected).val();
                txt = txt.substring(0, txt.indexOf("[") - 1);
                //Remove old
                view.lstSelectedColumns.find("option:eq(" + $(selected).index() + ")").remove();
                //Add to first list 
                view.lstAvailbleFields.append($('<option>').val(refName).text(txt));
                view.sortSelectOptions();
            });
        };
        ColumnOptionsView.prototype.moveSelectOptions = function (direction) {
            var view = this;
            var $op = view.lstSelectedColumns.find(':selected');
            if ($op.length) {
                (direction == 'up') ?
                    $op.first().prev().before($op) :
                    $op.last().next().after($op);
            }
        };
        ColumnOptionsView.prototype.sortSelectOptions = function () {
            //Sort 
            var view = this;
            var options = [];
            view.lstAvailbleFields.find("option").each(function (i, o) {
                options.push({ t: $(o).text(), v: o.value });
            });
            options.sort(function (o1, o2) {
                var t1 = o1.t.toLowerCase(), t2 = o2.t.toLowerCase();
                return t1 > t2 ? 1 : t1 < t2 ? -1 : 0;
            });
            view.lstAvailbleFields.find("option").each(function (i, o) {
                view.lstAvailbleFields.find("option:eq(" + $(o).index() + ")").replaceWith($('<option>')
                    .val(options[i].v)
                    .text(options[i].t));
            });
        };
        return ColumnOptionsView;
    }());
    exports.ColumnOptionsView = ColumnOptionsView;
    function Register() {
        var registrationForm = (function () {
            var callbacks = [];
            function inputChanged() {
                // Execute registered callbacks
                for (var i = 0; i < callbacks.length; i++) {
                    callbacks[i](isValid());
                }
            }
            function isValid() {
                // Check whether form is valid or not
                return true;
            }
            function getFormData() {
                // Get form values
                return {};
            }
            return {
                isFormValid: function () {
                    return isValid();
                },
                getFormData: function () {
                    return getFormData();
                },
                attachFormChanged: function (cb) {
                    callbacks.push(cb);
                }
            };
        })();
        // Register form object to be used accross this extension
        VSS.register("columnOptionsForm", registrationForm);
    }
    exports.Register = Register;
});
//# sourceMappingURL=ColumnsOptionsView.js.map