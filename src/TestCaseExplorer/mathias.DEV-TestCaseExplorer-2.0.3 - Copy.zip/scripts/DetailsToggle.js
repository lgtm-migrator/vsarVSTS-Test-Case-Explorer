//---------------------------------------------------------------------
// <copyright file="DetailsToggle.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file contains the logic 
//    for toggling the details pane.
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "VSS/Controls", "VSS/Controls/Splitter", "q"], function (require, exports, Controls, SplitterControls, Q) {
    "use strict";
    var Details = (function () {
        function Details() {
        }
        return Details;
    }());
    exports.Details = Details;
    var panelToggler = this;
    var DetailsPaneToggler = (function () {
        function DetailsPaneToggler() {
            this._isTestCaseDetailsPaneOn = function () {
                if (this._PanePosition && this._PanePosition !== "off") {
                    return true;
                }
                return false;
            };
        }
        DetailsPaneToggler.prototype.init = function (parent, farRightPanelCss, splitter, masterForm, detailsForm) {
            var deferred = $.Deferred();
            this._parent = parent;
            this._splitter = splitter;
            this._MasterForm = masterForm;
            this._detailsForm = detailsForm;
            this._$farRightPaneHubPivot = farRightPanelCss;
            var toggler = this;
            VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                var posReq = dataService.getValue("PanePosition", { scopeType: "User" });
                var widthReq = dataService.getValue("PreviousDetailsPaneWidth", { scopeType: "User" });
                var prevPanePosReq = dataService.getValue("PreviousPaneOnPosition", { scopeType: "User" });
                Q.all([posReq, widthReq, prevPanePosReq]).then(function (data) {
                    var savedPanePosition = data[0];
                    var savedDetailsPaneWidth = data[1];
                    var prevPanePosition = data[2];
                    if (savedDetailsPaneWidth == null || savedDetailsPaneWidth == "") {
                        savedDetailsPaneWidth = 160;
                    }
                    if (savedPanePosition == null || savedPanePosition == "") {
                        savedPanePosition = "off";
                    }
                    if (prevPanePosition != null && prevPanePosition != "" && prevPanePosition != "off") {
                        toggler._previousPaneOnPosition = prevPanePosition;
                    }
                    else {
                        toggler._previousPaneOnPosition = "right";
                    }
                    toggler.setTogglerAndPanesPosition(savedPanePosition, savedDetailsPaneWidth);
                    toggler._splitter._element.on('changed', function () {
                        toggler.saveWidth();
                    });
                    deferred.resolve(toggler);
                }, function (err) {
                }, function (err) {
                    console.log("Failed to get dataservice");
                    console.log(err);
                });
            });
            return deferred.promise();
        };
        DetailsPaneToggler.prototype.toggleDetailsPane = function () {
            if (this._isTestCaseDetailsPaneOn()) {
                this._showDetailsPane("off");
            }
            else {
                if (this._previousPaneOnPosition) {
                    this._showDetailsPane(this._previousPaneOnPosition);
                }
            }
        };
        DetailsPaneToggler.prototype.setPosition = function (pos) {
            this._showDetailsPane(pos);
        };
        DetailsPaneToggler.prototype.saveWidth = function () {
            var toggle = this;
            var width = toggle._PanePosition == "right" ? toggle._splitter.rightPane.width() : toggle._splitter.rightPane.height();
            width = (width == 0 ? 200 : width);
            toggle._previousPaneOnWidth = width;
            VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                // Set value in user scope
                dataService.setValue("PreviousDetailsPaneWidth", toggle._previousPaneOnWidth, { scopeType: "User" }).then(function (value) {
                    console.log("Save user pref " + value);
                }, function (err) {
                    console.log("Failed to save user value PreviousDetailsPaneWidth");
                    console.log(err);
                });
            }, function (err) {
                console.log("Failed to get dataservice");
                console.log(err);
            });
        };
        DetailsPaneToggler.prototype._showDetailsPane = function (position) {
            if (this._PanePosition !== position) {
                if (position === "off" && this._PanePosition) {
                    var toggle = this;
                    var width = toggle._PanePosition == "right" ? toggle._splitter.rightPane.width() : toggle._splitter.rightPane.height();
                    width = (width == 0 ? 200 : width);
                    toggle._previousPaneOnWidth = width;
                    toggle._previousPaneOnPosition = toggle._PanePosition;
                    VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                        // Set value in user scope
                        dataService.setValue("PreviousPaneOnPosition", toggle._PanePosition, { scopeType: "User" }).then(function (value) {
                            console.log("User scoped key value is PreviousPaneOnPosition " + value);
                        }, function (err) {
                            console.log("Failed to save user value PreviousDetailsPaneWidth");
                            console.log(err);
                        });
                        dataService.setValue("PreviousDetailsPaneWidth", toggle._previousPaneOnWidth, { scopeType: "User" }).then(function (value) {
                            console.log("User scoped key value is " + value);
                        }, function (err) {
                            console.log("Failed to save user value PreviousDetailsPaneWidth");
                            console.log(err);
                        });
                    }, function (err) {
                        console.log("cant get dataservice");
                    });
                }
                this._PanePosition = position;
            }
            VSS.getService(VSS.ServiceIds.ExtensionData).then(function (dataService) {
                // Set value in user scope
                dataService.setValue("PanePosition", position, { scopeType: "User" });
            });
            this.setTogglerAndPanesPosition(position, this._previousPaneOnWidth);
        };
        DetailsPaneToggler.prototype.setTogglerAndPanesPosition = function (position, width) {
            if (this._splitter == null) {
                this._splitter = Controls.Enhancement.getInstance(SplitterControls.Splitter, $(".right-hub-splitter"));
            }
            if (position === "off") {
                this._$farRightPaneHubPivot.css("display", "none");
                this._splitter.noSplit();
            }
            else {
                if (position === "right") {
                    this._splitter.horizontal();
                    this._splitter.split();
                }
                else {
                    this._splitter.vertical();
                    this._splitter.split();
                }
                this._splitter.toggleExpanded(true);
                this._splitter.resize(width);
                this._$farRightPaneHubPivot.css("display", "block");
            }
            this._PanePosition = position;
            this._previousPaneOnWidth = width;
        };
        return DetailsPaneToggler;
    }());
    exports.DetailsPaneToggler = DetailsPaneToggler;
});
//# sourceMappingURL=DetailsToggle.js.map