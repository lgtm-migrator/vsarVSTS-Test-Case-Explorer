//---------------------------------------------------------------------
// <copyright file="Common.ts">
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF 
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
// </copyright>
// <summary>
//    This is part of the Test Case Explorer extensions
//    from the ALM Rangers. This file contains the implementation
//    of Common code 
// </summary>
//---------------------------------------------------------------------
define(["require", "exports", "TFS/WorkItemTracking/RestClient", "q"], function (require, exports, WorkItemClient, Q) {
    "use strict";
    var WIQLConstants = (function () {
        function WIQLConstants() {
            this.TestCaseTypeName = "Test Case";
            this.TestCaseCategoryName = "Test Case Category";
            this.RequirementsCategoryName = "Requirement Category";
        }
        WIQLConstants.getWiqlConstants = function () {
            if (!this.constants) {
                this.constants = new WIQLConstants();
                this.constants.Init();
            }
            return this.constants;
        };
        WIQLConstants.prototype.Init = function () {
            try {
                var c = this;
                var witClient = WorkItemClient.getClient();
                var testCat = witClient.getWorkItemTypeCategory(VSS.getWebContext().project.id, "Microsoft.TestCaseCategory");
                var reqCat = witClient.getWorkItemTypeCategory(VSS.getWebContext().project.id, "Microsoft.RequirementCategory");
                Q.all([testCat, reqCat]).then(function (categories) {
                    c.TestCaseCategoryName = categories[0].name;
                    c.TestCaseTypeName = categories[0].defaultWorkItemType.name;
                    c.RequirementsCategoryName = categories[1].name;
                });
            }
            catch (e) {
                //this.constants = null;
                console.log(e);
            }
        };
        return WIQLConstants;
    }());
    exports.WIQLConstants = WIQLConstants;
    function getTestResultCellContent(rowInfo, dataIndex, expandedState, level, column, indentIndex, columnOrder) {
        var outcome = this.getColumnValue(dataIndex, column.index);
        var d = $("<div class='grid-cell'/>").width(column.width || 100);
        var dIcon = $("<div class='testpoint-outcome-shade icon bowtie-icon-small'/>");
        dIcon.addClass(getIconFromTestOutcome(outcome));
        d.append(dIcon);
        var dTxt = $("<span />");
        dTxt.text(outcome);
        d.append(dTxt);
        return d;
    }
    exports.getTestResultCellContent = getTestResultCellContent;
    function getIconFromTestOutcome(outcome) {
        var icon = "";
        switch (outcome) {
            case "NotApplicable":
                icon = "icon-tfs-tcm-not-applicable";
                break;
            case "Blocked":
                icon = "icon-tfs-tcm-block-test";
                break;
            case "Passed":
                icon = "icon-tfs-build-status-succeeded";
                break;
            case "Failed":
                icon = "icon-tfs-build-status-failed";
                break;
            case "None":
                icon = "icon-tfs-tcm-block-test";
                break;
            case "DynamicTestSuite":
                icon = "icon-tfs-build-status-succeeded";
                break;
        }
        return icon;
    }
    exports.getIconFromTestOutcome = getIconFromTestOutcome;
    function MergeColumnLists(lst1, lst2) {
        var a = lst1.concat(lst2);
        var seen = {};
        return a.filter(function (item) {
            return seen.hasOwnProperty(item.field) ? false : (seen[item.field] = true);
        });
    }
    exports.MergeColumnLists = MergeColumnLists;
});
//# sourceMappingURL=Common.js.map